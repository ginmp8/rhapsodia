---
name: magia
description: use when asked to execute, implement, debug, test, validate, harden, document, unblock, refactor, simplify, de-abstract, adapt legacy execution records into current magia-owned artifacts, or package bounded target repository work from current code and selected mago specs. supports adhoc direct code/config/docs changes, ralph execution from typed planning contracts without a required board, best-effort adapt of legacy execution logs into implementation-notes.md and validation-evidence.md, and execution-grounded technical documentation. do not use for product governance, stakeholder updates, roadmap bookkeeping, release notes, portfolio reporting, prd refinement, broad planning, or claims without current evidence.
---

# MAGIA

MAGIA owns bounded repository implementation, debugging, tests, validation, hardening, behavior-preserving simplification, execution-state sync, and execution-grounded technical documentation. Current code, runtime output, tests, and validated owner-scoped input contracts are source of truth. Board contracts apply only in the explicit legacy profile.


## Default storage and artifact orchestration

Use [artifact-native operation](references/artifact-native.md) before all storage-specific guidance. Each domain decides its own files, writes only its own sources, validates content, publishes sidecars and returns uniform `artifact_actions`. No Workspace, Board, cycle or shared registry is required. Retained Board-specific commands/examples apply only to explicitly selected `legacy-board` maintenance/migration; their storage mechanics never override the native default. Preserve all domain authority, traceability, risk, privacy, recovery and evidence gates.


## Portability

The Agent Skills package is the host-neutral semantic core. `agents/openai.yaml` is an optional OpenAI adapter and must not be required for correctness. Resolve `<PYTHON>` to an available Python 3.11+ launcher; use package-relative paths and capability-based execution; do not depend on Bash, fixed install paths, or vendor-private APIs for core behavior.

## Coordinated reproducibility contract

This package participates in ecosystem release `2.0.0` with shared-contract version `1.0.0`. Use [ecosystem ownership](references/ecosystem-ownership-contract.json), [reproducibility](references/ecosystem-reproducibility-contract.json), and the frozen [cross-skill scenarios](evals/ecosystem-cross-skill-scenarios.json) as release gates. `scripts/validate_ecosystem_reproducibility.py` is package-local; it must not read/import peer skill packages. Package receipts bind baseline, frozen candidate, shared-contract, and archive hashes; the coordinator may combine those receipts into ecosystem compatibility evidence without creating runtime coupling.

## Distributed ecosystem routing

Use the [routing contract](references/ecosystem-routing-contract.md) and [lifecycle](references/ecosystem-lifecycle.md). Perform only the executable phase, preserve repeated phases, then hand off evidence; never absorb planning/governance. `scripts/route_ecosystem_request.py` is read-only; `scripts/handoff_ledger.py` stores transport state only.

## Ecosystem contracts

Use the strict [ecosystem handoff contract](references/ecosystem-handoff-contract.md) through `scripts/ecosystem_handoff.py`: consume `mago_to_magia`; produce `magia_to_mago` and `magia_to_nomia`. Apply [priority ownership](references/priority-contract.md) read-only. Reject mixed versions, generic priority, wrong-owner content, content/privacy-metadata contradictions, missing durable-artifact privacy lineage, unverified source-handoff authenticity when authenticity is claimed, and unsupported schemas.

## Scope Boundary

Planning-origin artifacts are execution inputs, not runtime prohibitions. MAGIA is independent: local contracts/validators never import, execute, or read peer skill internals at runtime. Never use implementation requirement alone as the blocker.

MAGIA does not own governance, roadmap/portfolio, stakeholder/release communication, PRD/acceptance rewrites, task definition/resequencing, broad planning, or unvalidated completion. It may fill implementation detail inside current intent. Material intent, architecture, public contract, data/security, sequencing, or user-behavior changes require Mago; commitments and business-risk decisions require Nomia.

## Role Model

- Nomia: requester/owner/dates, business priority, roadmap, governance/release state.
- Mago: requirements, design, planned decisions/tasks/validation, execution handoff.
- Magia: code/config/docs implementation, tests, runtime evidence, execution decisions/records.

## Technical Artifact Ownership

MAGIA may write `implementation-notes.md`, `complexity-reduction-evidence.md`, implementation ADRs, `validation-evidence.md`, `runbook.md`, migration/contract/observability/security notes, `troubleshooting.md`, and `technical-gap-note.md`. Native mode writes execution state/evidence only under its own artifact root; all Mago and Nomia artifacts are read-only, including planning `tasks.md`, `notes.md`, and `validation.md`. Narrow shared-surface sync in [legacy ownership](references/shared-artifact-ownership.md) applies only to explicit legacy-board maintenance. Never rewrite planning intent.

## Technical Decision Authority

Implementation decisions require inspected evidence, necessity, product-intent fit, and truthful validation. Escalate material planned architecture/contract/data/security/cross-service/user-visible changes to Mago and delivery commitments/business risk to Nomia.

## Load Order

1. Classify execution, blocker, documentation, or handoff.
2. Load [canonical paths](references/canonical-paths.md), [common execution](references/common-execution.md), and [execution entry](references/execution-entry.md).
3. When needed load [repository orientation](references/repository-orientation.md), [senior discipline](references/senior-engineering-discipline.md), and triggered [risk escalation](references/risk-and-change-escalation.md), [execution profiles](references/execution-profiles.md), [complexity reduction](references/complexity-reduction-execution.md), or [multi-repository execution](references/multi-repository-execution.md). Load [run state/recovery](references/run-state-and-recovery.md) only for resumable, stateful, interrupted, or governed execution. When a parent controller delegates a `workflow-plan/v2` checkpoint candidate/repair, also load [gated checkpoint execution](references/gated-checkpoint-execution.md). Load [failure/recovery taxonomy](references/failure-recovery-taxonomy.md) only after a failed or blocked step requires a repair/retry/rollback/stop/handoff decision.
4. For native RALPH load [native execution](references/artifact-native.md), [planning handoff](references/planning-handoff.md), and [safe parallelism](references/safe-parallelism.md) when parallel execution is selected. Load the [Board contract](references/board-contract.md) only for explicit legacy-board compatibility.
5. Load exactly one mode: [ADHOC](references/modes/adhoc.md), [RALPH](references/modes/ralph.md), or [ADAPT](references/modes/adapt.md).
6. Load [execution records](references/artifacts/execution-records.md), [evidence](references/artifacts/execution-evidence.md), [developer standards](references/developer-artifact-standards.md), and [technical documentation](references/technical-documentation.md) only when writing.
7. Before closure load [validation selection](references/validation-selection.md) and [validation/closure](references/validation-and-closure.md). `scripts/select_validation.py` is preliminary; `scripts/select_validation_checks.py` is canonical once surfaces are known.
8. Load [convergence](references/convergence-and-validation.md), [public adapters](references/public-artifact-adapters.md), [Markdown rules](references/markdown-writing.md), [quickstarts](references/quickstarts.md), [resource map](references/resource-map.md), or [package delivery](references/package-delivery.md) only when triggered.

## Mode Selection

| Mode | Use | Closure |
|---|---|---|
| ADHOC | direct repo code/config/tests/scripts/developer docs | smallest safe change passes targeted proof |
| RALPH | selected task or dependency-safe batch from a Mago contract | readiness, checks, traceability, and owner-local execution-state gates pass |
| ADAPT | legacy execution records into current Magia evidence | current state validates or gaps stay explicit |

Risk profile is independent of mode; [execution profiles](references/execution-profiles.md) are the canonical control-depth contract.

## Required Inputs Before Mutation

- ADHOC: repo/file scope, behavior, allowed/blocked paths, proving check.
- RALPH: validated planning handoff, source-bound spec/task/work-item, repo scope, PRD objective, acceptance criterion, planned validation/expected result, dependencies, validators, clues.
- ADAPT: explicit legacy source and owner destination, readable legacy records, permission for Magia-owned outputs.
- Docs/refactor/package: artifact/scope, evidence, preserved behavior, validation, rollback/stops, output path.

## Execution Workflow

1. Resolve mode, scope, risk, ownership, and compact start card.
2. Define success; inspect relevant code, patterns, contracts, and evidence.
3. Make the smallest sufficient change; avoid speculation and unrelated cleanup. For a gated checkpoint delegation, produce/repair only that checkpoint candidate and do not self-promote it or close the canonical phase.
4. For simplification, establish a safety net, preserve behavior, remove one seam at a time, and record before/after evidence.
5. Use deterministic local scripts and confined paths; reject traversal, symlink escape, stale state, and unsafe lock takeover.
6. In RALPH, require task-to-intent/validation traceability and dependency-safe order; close only with a passed check and recoverable journaled state transaction.
7. Validate incoming handoffs, run the narrowest Magia-owned proof plus applicable validators, and emit downstream envelopes only from current evidence. An independently required verifier/reviewer gate remains separate from Magia self-validation.
8. For checkpointed execution, return the candidate identity to the parent controller; repairs create a new candidate and invalidate affected prior gate passes. Final task/phase completion waits for all required checkpoint promotions plus normal Magia closure evidence.
9. Report changes, checks, risk, privacy lineage, and handoff.

## Operating Rules

Preserve unknowns; never invent behavior, ownership, state, branches/PRs/releases, validation, deployment, production evidence, or privacy classification. Match existing conventions unless unsafe. Keep outputs inside authorized roots. Never repeat secrets, credentials, PII, private keys, or sensitive logs; redact and escalate plausible exposure. Use lowercase canonical identifiers. Continue unattended loops only while scoped, honest, and verifiable.

## Stop Conditions

Stop/handoff when work belongs to planning/governance; inputs required by the selected mode cannot be resolved (ADHOC: repo/file scope, behavior, allowed/blocked paths, proving check; RALPH: source-bound spec/task/work-item linkage plus planned proof); execution requires changing intent, acceptance, task definition/order, architecture, public contract, data/security, or user behavior beyond authority; simplification lacks equivalence/rollback; state conflicts cannot be mechanically healed; writes escape scope; privacy lineage is absent; or no truthful validation alternative exists.

## Output Contract

Include the verified uniform `artifact_actions` array and `artifact_actions_validation` from native publication; report source changes separately from disposable projection refresh.

Include only applicable sections: mode/risk/scope; changes; technical artifacts; checks (`pass`, `fail`, `blocked`, `skipped`, `not-run`, with a reason whenever status is not `pass`); execution-record changes; decisions/assumptions/blockers/risks/trade-offs; structured downstream evidence. Never claim completion without current proof.

## Package Requests

For export load [packaging isolation](references/packaging-isolation.md), obtain externally executed tree-bound evidence, and run `scripts/package_skill.py`. Require `scripts/validate_ecosystem_release.py` for coordinated release. The packager never executes target code.

## Validation Checklist

Confirm mode/ownership, authorized paths, required references, touched artifact validators, proving checks, truthful RALPH readiness/traceability/state, current handoff/privacy contracts, no scaffold/fabricated evidence/broken links/invalid IDs/unscannable content, and folder/archive gates. Label skipped checks; never claim live routing, production behavior, or readiness not measured.

## Activation Examples

ADHOC: fix a failing parser test and run its targeted command. RALPH: execute one selected Mago task and sync evidence. Docs: record an implementation ADR forced by runtime evidence. Negative: PRD, roadmap, stakeholder status, release notes, governance decision. Ambiguous: resolve owner and the next safe action before mutation. Native scenario oracles use `expected_owner: mago|magia|nomia|none`, `expected_activation: true|false|null`, and boolean `diagnostic_entry_allowed`; `null` means owner is unresolved, not that Magia owns the request.
