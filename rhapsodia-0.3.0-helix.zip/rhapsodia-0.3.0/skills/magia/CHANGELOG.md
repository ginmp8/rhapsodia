# Changelog

## [2.0.0] - 2026-10-03

### Breaking
- Artifact-native producer roots replace shared Board storage as the default.
- Packaging requires external executed, tree-bound validation evidence; target scripts are never executed by the packager.
- Canonical workers return uniform, live-bound artifact_actions. Workspace is optional and derived-only.

### Added and fixed
- Independent artifact publication, revision checks, tombstones, source hash validation, and bounded discovery.
- Owner-side legacy copy migration with preserved originals and hash-approved recovery.
- Native planning identity/contracts and execution evidence with no cross-owner writeback.
- Strict legacy path, date, dependency and manifest checks for compatibility mode.
- Frozen historical evaluator bytes remain immutable; explicit hashes replace migration-version coupling.


## Unreleased

- Add optional gated-checkpoint execution guidance for externally orchestrated `workflow-plan/v2` runs without changing Magia domain ownership or the ecosystem handoff schema.
- Separate intermediate checkpoint candidate/repair evidence from canonical task/phase completion.
- Preserve independent verifier/reviewer gates: Magia may repair production code but must not self-promote a failed or stale gate.
- Release metadata remains at the current coordinated ecosystem release until Mago/Nomia/Magia are intentionally released together.
- Compatibility impact: backward-compatible execution guidance only; no shared schema, ownership contract, routing contract, or coordinated release identity changes.

## [1.10.1] - 2026-09-22

- Make the portable Agent Skills core explicit and normalize documented Python invocations to the host-resolved `<PYTHON>` launcher.
- Add package-output preflight so archives and JSON evidence cannot alias or be written inside the source skill tree before validation/packaging begins.
- Remove generated cache/bytecode residue from the distributable source tree; execution authority, ADHOC/RALPH/ADAPT semantics, routing, handoffs, and validation contracts are unchanged.
- Compatibility impact: compatible coordinated patch; shared contract schemas remain unchanged and exact-version policy requires all three 1.10.1 packages together.

## [1.10.0] - 2026-09-19

- Integrate execution-profile, failure-taxonomy, and resumable-run-state resources into progressive loading and fail-closed reachability validation; structurally gate the frozen booster activation corpus without claiming live-model metrics.
- Add a frozen, package-local cross-skill reproducibility contract/suite covering routing, handoffs, ownership, priority, privacy, freshness, replay, closure, and safe reruns.
- Preserve Magia as execution/validation owner only while strengthening deterministic route identity, wrong-owner rejection evidence, package receipts, and handoff-ledger last-known-good recovery/receipts.
- Add explicit ownership contract and coordinated migration path without peer runtime reads/imports.
- Compatibility impact: compatible coordinated minor; ADHOC/RALPH/ADAPT authority is unchanged, handoff schema remains `3.0.0`, priority schema remains `2.0.0`, and exact-version policy requires all three 1.10.0 packages together.



## [1.9.4] - 2026-08-18

- Make the live-routing harness unit tests self-contained so the complete Magia test suite passes from the standalone skill package without sibling Mago/Nomia checkouts.
- Preserve the runtime harness contract: real prepare/evaluate commands still require explicit Mago, Magia, and Nomia roots and verify byte-equivalent routing corpora.
- Compatibility impact: compatible coordinated patch; no ownership, lifecycle, ADHOC/RALPH behavior, handoff schema `3.0.0`, priority schema `2.0.0`, or routing-oracle semantic change. Live-model routing remains unmeasured.

## [1.9.3] - 2026-08-18

- Normalize native activation oracles with explicit owner, tri-state activation, and diagnostic-entry semantics; ambiguous requests now keep ownership unresolved.
- Make selected-task linkage and canonical closure evidence RALPH-only; ADHOC requires bounded repository/file scope, preserved behavior, and a proving check instead of board/spec/task context.
- Align validation output statuses to `pass | fail | blocked | skipped | not-run` and require a reason for every non-pass result.
- Add explicit ADHOC activation coverage for parser fixes and behavior-preserving refactors without a governed board/spec.
- Add a shared adversarial routing case that rejects a forced Magia owner while lifecycle/current owner is unresolved.
- Compatibility impact: compatible coordinated patch; ownership, lifecycle, handoff schema `3.0.0`, priority schema `2.0.0`, and exact-version policy are unchanged. Live-model routing remains unmeasured.

## [1.9.2] - 2026-08-17

- Fix `current_owner` routing so a current Nomia phase plus implementation intent inserts the mandatory Mago bridge instead of failing on a forbidden direct handoff.
- Clarify same-owner phase semantics: consecutive intents coalesce into one owner phase while ordered intents and non-consecutive repeated owner phases remain preserved.
- Make the 365-day durable-artifact cap explicitly stricter than the 3650-day handoff limit; persistence remains fail-closed when inherited retention exceeds the durable-artifact policy.
- Strengthen artifact privacy lineage with canonical handoff references, source-handoff integrity verification when source evidence is supplied, and exact-inheritance checks. Structural lineage alone no longer implies source authenticity.
- Keep routing activation evidence explicitly structural; live-model precision and recall remain unmeasured.
- Compatibility impact: compatible coordinated patch; handoff schema `3.0.0`, priority schema `2.0.0`, ownership, and payload contracts are unchanged. Exact-version policy still requires upgrading or rolling back all three skills together.

## [1.9.1] - 2026-07-23

- Preserve ordered and repeated lifecycle phases with a corpus-backed executable routing oracle.
- Reject legacy Nomia ops schema v1 outside explicit governance adaptation.
- Verify privacy declarations against content and propagate compact privacy lineage to durable artifacts.
- Define conditional `execution_sequence.rank` semantics for draft/blocked versus ready handoffs.
- Add deterministic privacy, routing, compatibility, and regression gates without changing domain authority.

## 1.9.0 - 2026-07-23

- Added privacy-minimized contract-v3 handoffs with workflow lineage.
- Added deterministic read-only routing and persistent handoff ledger contracts.
- Preserved independent Nomia, Mago, and Magia ownership.
- Compatibility impact: breaking coordinated release; contract-v2 envelopes and mixed package versions are rejected before mutation.

## [1.8.0] - 2026-07-23

- Declare PyYAML as a runtime dependency through `requirements.txt` and `release.json`, add runtime dependency validation, clean-environment YAML smoke coverage, and source/archive package gates.
- Harden strict handoff v2 consumption with closed payloads, bounded freshness, future-timestamp rejection, non-empty evidence references, stable reason codes, and non-actionable draft exit semantics.
- Remove residual `contract-v1`, generic `priority`, and `order_hint` guidance from current Magia instructions and extend semantic instruction validation.
- Add the coordinated release attestation ledger and external live-routing evidence contract without runtime peer imports or ownership transfer.
- Preserve ADHOC, RALPH, ADAPT, execution authority, current identifiers, and exact coordinated compatibility.

### Compatibility

- Coordinated exact ecosystem release `1.8.0`; all three packages must move together.
- Handoff schema remains `2.0.0`; draft consumption now fails process control by default and requires explicit inspection allowance.

## [1.7.0] - 2026-07-22
- Integrate convergence validation, public artifact adapters, and both validation selectors into the canonical load order and resource map.
- Add a fail-closed resource-integration validator and distinguish preliminary risk inference from explicit proof-category selection.
- Clarify independent one-owner context loading without introducing a cross-skill execution facade.

- Execute the complete pytest suite inside the MAGIA package gate with collected/executed/pass/fail counts and a suite digest.
- Replace obsolete positive activation paths with canonical board, cycle, and spec identities.
- Add distributed routing, lifecycle, shared provenance, negative ecosystem harness, release metadata, and declared development requirements.
- Preserve MAGIA execution ownership and coordinated exact compatibility with Mago and Nomia `1.7.0`.

### Compatibility

- Coordinated exact ecosystem release `1.7.0`; mixed versions remain rejected before mutation or closure.


## 1.6.0 - 2026-07-22

- Adopt exact ecosystem compatibility with Mago and Nomia `1.6.0`.
- Upgrade ecosystem handoffs to strict schema v2 with deterministic ids, exact package versions, no unsupported aliases, and object-shaped priority contracts.
- Carry and validate byte-equivalent priority, handoff, and compatibility contracts locally without runtime dependency on peer skills.
- Add the integrated Nomia-to-Mago-to-Magia reconciliation and closure harness.
- Reject unsupported handoff schemas and aliases; only the current strict v2 contract is accepted.

## 1.5.0 - 2026-07-22

- Added a versioned, mechanically validated ecosystem handoff contract carried locally by MAGIA.
- Added a local producer/consumer CLI for `mago_to_magia`, `magia_to_mago`, and `magia_to_nomia` envelopes with provenance, freshness, conflicts, unknowns, package versions, and state-mapping metadata.
- Added positive, negative, stale, conflict, authority, mapping, and round-trip tests without introducing runtime dependency on Mago or Nomia.
- Integrated the shared contract into planning-handoff, validation/closure, package validation, archive validation, and resource discovery.

## 1.4.0 - 2026-07-21

- Added a compact execution-entry contract for faster safe starts while preserving ADHOC, RALPH, ADAPT, planning, and governance boundaries.
- Added deterministic read-only repository orientation, conservative execution-wave analysis, and risk-based validation-category selection without executing repository commands or inventing results.
- Added a non-authoritative execution and recovery projection covering task/evidence state, live/dead locks, transaction journals, blockers, and the next safe action.
- Added progressive quickstarts for direct work, board execution, legacy adaptation, governed changes, blocked handoffs, validation, and recovery.
- Added 20 focused tests for the new capabilities; the complete suite now contains 92 passing tests.
- Preserved truthful evidence statuses, smallest-sufficient-change discipline, recoverable state transactions, source-of-truth authority, and Mago/Nomia ownership boundaries.

## 1.3.0 - 2026-07-21

- Added explicit standard/governed risk escalation for contract, data, security, compliance, availability, financial, and multi-repository work.
- Added evidence precedence, change classification, compatibility, migration, rollback/recovery, operations, and authority gates without changing MAGIA ownership boundaries.
- Converted mode selection into a compact evidence-and-closure matrix and integrated all package resources through explicit progressive-loading links.
- Added release compatibility discipline requiring truthful changelog/version decisions, final-state folder/archive validation, and SHA-256 evidence.
- Preserved existing runtime behavior and passed the full 72-test suite plus package, boundary, instruction, planning-handoff, security, and structural gates.

## 1.2.0 - 2026-07-21

- Require selected RALPH tasks to resolve to current PRD intent and a planned validation check through explicit anchors or deterministic legacy semantic linkage.
- Require dependency-safe task order unless planning explicitly marks a task `[parallel]` or `[independent]`.
- Resolve validation-evidence Traceability sources against the selected task or current PRD objective/acceptance criterion before any done-state mutation.
- Add adversarial regression tests proving unrelated tasks and invented traceability sources cannot authorize closure.
- Centralize package inclusion/exclusion policy so validation scans exactly the files eligible for the archive and ignores only known generated artifacts.
- Normalize activation scenario schema for deterministic shared harness validation while retaining regression/adversarial provenance in `suite`.

## 1.1.1 - 2026-07-20

- Hardened transaction recovery against target and backup traversal, symlinks, malformed journals, duplicate entries, and unauthorized execution-state files.
- Added dead-owner lock recovery, live-owner protection, incomplete pre-journal cleanup, process-start metadata, directory durability sync, and preflight snapshot drift detection.
- Strengthened RALPH readiness semantics so canonical sections, concrete criteria, executable validation actions, and explicit expected outcomes are required; negated and scaffold-marker content is rejected.
- Added nine adversarial regression tests covering the newly enforced G2, G5, and G8 controls.
- Bound Traceability rows to the same passed executed check and rejected meta-only or explicitly absent evidence.
- Made package security scanning fail closed for oversized, binary, and undecodable content while narrowing redacted-example handling to the matched assignment value.
- Added real calendar-date validation for cycle IDs, spec IDs, and execution dates.

## 1.1.0 - 2026-07-20

- Added semantic validation evidence and task-to-check traceability gates.
- Added recoverable multi-file execution-state transactions with candidate validation.
- Enforced authorized roots for scaffold writes and blocked symlink escapes.
- Added secret-content and symlink scanning for source folders and packaged archives.
- Added concrete RALPH readiness checks for objectives, acceptance criteria, tasks, and validation plans.
